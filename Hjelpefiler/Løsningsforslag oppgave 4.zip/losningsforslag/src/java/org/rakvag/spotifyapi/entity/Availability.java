package org.rakvag.spotifyapi.entity;

public class Availability {
	private String territories;
	
	public String getTerritories() {
		return territories;
	}
}
